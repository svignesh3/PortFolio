import { Mail, Linkedin, Github } from "lucide-react";

const links = [
  { icon: Mail, label: "Email", value: "hello@example.com", href: "mailto:hello@example.com" },
  { icon: Linkedin, label: "LinkedIn", value: "/in/vigneshwaran", href: "https://linkedin.com" },
  { icon: Github, label: "GitHub", value: "@vigneshwaran", href: "https://github.com" },
];

export function Contact() {
  return (
    <section id="contact" className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-medium uppercase tracking-widest text-gradient">Contact</p>
          <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">
            Let's connect and build <span className="text-gradient">something great</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Open to roles, freelance work and collaborations. Drop a message — I usually reply within a day.
          </p>

          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
            {links.map(({ icon: Icon, label, value, href }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer"
                className="glass group rounded-2xl p-6 text-left transition-all hover:-translate-y-1 hover:shadow-glow"
              >
                <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-brand text-primary-foreground shadow-glow">
                  <Icon className="h-4 w-4" />
                </div>
                <div className="text-sm font-semibold">{label}</div>
                <div className="mt-1 truncate text-sm text-muted-foreground group-hover:text-foreground">
                  {value}
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>

      <footer className="mt-20 border-t border-border">
        <div className="container mx-auto flex flex-col items-center justify-between gap-3 px-4 py-8 text-sm text-muted-foreground sm:flex-row">
          <span>© {new Date().getFullYear()} Vigneshwaran S. All rights reserved.</span>
          <span>Crafted with care · Tamil Nadu, India</span>
        </div>
      </footer>
    </section>
  );
}
