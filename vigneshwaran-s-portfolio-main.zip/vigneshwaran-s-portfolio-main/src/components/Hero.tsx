import { Github, Linkedin, Mail, Download, ArrowRight, GraduationCap, MapPin, Award } from "lucide-react";
import profile from "@/assets/profile.jpg";

const infoCards = [
  { icon: GraduationCap, label: "Graduate", sub: "2024" },
  { icon: MapPin, label: "Tamil Nadu", sub: "India" },
  { icon: Award, label: "B.Tech", sub: "Degree" },
];

export function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center pt-28 pb-16">
      <div className="container mx-auto grid grid-cols-1 items-center gap-12 px-4 lg:grid-cols-2">
        {/* Left */}
        <div className="animate-fade-up">
          <div className="glass mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs">
            <span className="h-2 w-2 animate-pulse-glow rounded-full bg-gradient-brand" />
            <span className="text-muted-foreground">Available for opportunities</span>
          </div>

          <h1 className="text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            Vigneshwaran <span className="text-gradient">S</span>
          </h1>

          <p className="mt-4 text-lg font-medium text-muted-foreground sm:text-xl">
            Software Developer & UI/UX Designer
          </p>

          <p className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
            Building scalable web applications and designing intuitive digital experiences.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#projects"
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-6 py-3 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:scale-105"
            >
              View Projects
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="/resume.pdf"
              download
              className="glass inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium transition-all hover:scale-105 hover:shadow-glow"
            >
              <Download className="h-4 w-4" /> Download Resume
            </a>
          </div>

          <div className="mt-8 flex items-center gap-3">
            {[
              { icon: Linkedin, href: "https://linkedin.com", label: "LinkedIn" },
              { icon: Github, href: "https://github.com", label: "GitHub" },
              { icon: Mail, href: "mailto:hello@example.com", label: "Email" },
            ].map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                target="_blank"
                rel="noreferrer"
                className="glass flex h-11 w-11 items-center justify-center rounded-full transition-all hover:scale-110 hover:shadow-glow"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        {/* Right */}
        <div className="relative flex flex-col items-center animate-fade-in">
          <div className="relative">
            <div
              className="absolute inset-0 animate-pulse-glow rounded-full bg-gradient-brand blur-3xl opacity-50"
              aria-hidden
            />
            <div className="relative rounded-full bg-gradient-brand p-1.5 shadow-glow">
              <div className="rounded-full bg-background p-2">
                <img
                  src={profile}
                  alt="Vigneshwaran S"
                  width={384}
                  height={384}
                  className="h-72 w-72 rounded-full object-cover sm:h-80 sm:w-80 lg:h-96 lg:w-96"
                />
              </div>
            </div>
            <div className="glass-strong absolute -right-2 top-8 hidden rounded-2xl px-4 py-3 shadow-card sm:block animate-float">
              <div className="text-xs text-muted-foreground">Experience</div>
              <div className="text-sm font-semibold">Full-Stack</div>
            </div>
            <div className="glass-strong absolute -left-2 bottom-12 hidden rounded-2xl px-4 py-3 shadow-card sm:block animate-float" style={{ animationDelay: "1.5s" }}>
              <div className="text-xs text-muted-foreground">Designs</div>
              <div className="text-sm font-semibold">UI / UX</div>
            </div>
          </div>

          <div className="mt-8 grid w-full max-w-md grid-cols-3 gap-3">
            {infoCards.map(({ icon: Icon, label, sub }) => (
              <div
                key={label}
                className="glass rounded-2xl p-4 text-center transition-all hover:scale-105 hover:shadow-glow"
              >
                <Icon className="mx-auto mb-2 h-5 w-5 text-gradient" style={{ color: "oklch(0.70 0.18 270)" }} />
                <div className="text-sm font-semibold">{label}</div>
                <div className="text-xs text-muted-foreground">{sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
