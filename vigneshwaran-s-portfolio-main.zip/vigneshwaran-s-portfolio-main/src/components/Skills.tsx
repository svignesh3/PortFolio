import { Code2, Layout, BarChart3, Palette, Wrench } from "lucide-react";

const groups = [
  { icon: Code2, title: "Programming", items: ["Java", "Python", "SQL"] },
  { icon: Layout, title: "Frontend", items: ["JavaScript", "React.js", "HTML", "CSS"] },
  { icon: BarChart3, title: "Data & Analytics", items: ["Data Analysis", "Excel", "Chart.js"] },
  { icon: Palette, title: "UI/UX Design", items: ["Figma", "Wireframing", "Prototyping", "UX Principles"] },
  { icon: Wrench, title: "Tools", items: ["Git", "GitHub", "Firebase", "VS Code"] },
];

export function Skills() {
  return (
    <section id="skills" className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="mb-14 text-center">
          <p className="text-sm font-medium uppercase tracking-widest text-gradient">Skills</p>
          <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">
            What I bring to the table
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A blend of engineering, design and analytical skills used to ship polished products.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {groups.map(({ icon: Icon, title, items }) => (
            <div
              key={title}
              className="group glass relative overflow-hidden rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-glow"
            >
              <div className="absolute inset-0 -z-10 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                   style={{ background: "var(--gradient-primary)", filter: "blur(40px)" }} />
              <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-brand text-primary-foreground shadow-glow">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold">{title}</h3>
              <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground">
                {items.map((i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-gradient-brand" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
