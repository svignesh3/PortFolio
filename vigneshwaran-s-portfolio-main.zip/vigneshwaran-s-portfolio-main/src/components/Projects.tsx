import { useState } from "react";
import { Github, ExternalLink } from "lucide-react";
import iot from "@/assets/project-iot.jpg";
import fitness from "@/assets/project-fitness.jpg";
import data from "@/assets/project-data.jpg";
import portfolio from "@/assets/project-portfolio.jpg";

type Category = "All" | "Development" | "Data" | "Design";

const projects: {
  title: string;
  description: string;
  image: string;
  tech: string[];
  category: Exclude<Category, "All">;
  github: string;
  demo: string;
}[] = [
  {
    title: "Smart IoT Dashboard",
    description: "Real-time IoT monitoring dashboard with live charts that improved decision speed by 40%.",
    image: iot,
    tech: ["React", "Firebase", "Chart.js", "Node.js"],
    category: "Development",
    github: "#",
    demo: "#",
  },
  {
    title: "Fitness Tracker App",
    description: "Mobile-first fitness app delivering personalized workouts and habit tracking for 1k+ users.",
    image: fitness,
    tech: ["React Native", "Firebase", "Figma"],
    category: "Design",
    github: "#",
    demo: "#",
  },
  {
    title: "Data Analysis Project",
    description: "End-to-end analysis pipeline turning raw data into actionable insights with rich visualizations.",
    image: data,
    tech: ["Python", "Pandas", "Excel", "Chart.js"],
    category: "Data",
    github: "#",
    demo: "#",
  },
  {
    title: "Portfolio Website",
    description: "Premium personal portfolio crafted with glassmorphism, gradients and silky animations.",
    image: portfolio,
    tech: ["React", "TypeScript", "Tailwind"],
    category: "Design",
    github: "#",
    demo: "#",
  },
];

const filters: Category[] = ["All", "Development", "Data", "Design"];

export function Projects() {
  const [active, setActive] = useState<Category>("All");
  const filtered = active === "All" ? projects : projects.filter((p) => p.category === active);

  return (
    <section id="projects" className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="mb-10 text-center">
          <p className="text-sm font-medium uppercase tracking-widest text-gradient">Projects</p>
          <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">
            Selected work
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A handful of projects that highlight my approach to design and engineering.
          </p>
        </div>

        <div className="mb-10 flex flex-wrap items-center justify-center gap-2">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                active === f
                  ? "bg-gradient-brand text-primary-foreground shadow-glow"
                  : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {filtered.map((p) => (
            <article
              key={p.title}
              className="group glass overflow-hidden rounded-3xl transition-all duration-500 hover:-translate-y-1 hover:shadow-glow"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  width={1024}
                  height={640}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                <span className="absolute left-4 top-4 glass rounded-full px-3 py-1 text-xs">
                  {p.category}
                </span>
              </div>

              <div className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <h3 className="text-xl font-semibold">{p.title}</h3>
                  <div className="flex shrink-0 items-center gap-2">
                    <a
                      href={p.github}
                      aria-label="GitHub"
                      className="glass flex h-9 w-9 items-center justify-center rounded-full transition-all hover:scale-110 hover:shadow-glow"
                    >
                      <Github className="h-4 w-4" />
                    </a>
                    <a
                      href={p.demo}
                      aria-label="Live demo"
                      className="glass flex h-9 w-9 items-center justify-center rounded-full transition-all hover:scale-110 hover:shadow-glow"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.tech.map((t) => (
                    <span key={t} className="rounded-full border border-border bg-secondary/50 px-3 py-1 text-xs text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
