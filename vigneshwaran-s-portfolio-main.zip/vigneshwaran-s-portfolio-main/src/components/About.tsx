import { useState } from "react";
import { ArrowRight } from "lucide-react";

export function About() {
  const [expanded, setExpanded] = useState(false);

  return (
    <section id="about" className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="glass-strong mx-auto max-w-4xl overflow-hidden rounded-3xl p-10 shadow-card sm:p-14">
          <p className="text-sm font-medium uppercase tracking-widest text-gradient">About</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Designer who codes — engineer who cares about craft.
          </h2>

          <p className="mt-6 text-base leading-relaxed text-muted-foreground sm:text-lg">
            I am a B.Tech graduate transitioning into Software Development and UI/UX Design,
            passionate about building scalable applications and creating user-friendly digital experiences.
          </p>

          {expanded && (
            <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg animate-fade-up">
              I enjoy bridging the gap between design and engineering — translating thoughtful interfaces
              into clean, performant code. Currently exploring opportunities where I can contribute to
              meaningful products and grow alongside great teams.
            </p>
          )}

          <button
            onClick={() => setExpanded(!expanded)}
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-brand px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:scale-105"
          >
            {expanded ? "Show Less" : "Read More"}
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
