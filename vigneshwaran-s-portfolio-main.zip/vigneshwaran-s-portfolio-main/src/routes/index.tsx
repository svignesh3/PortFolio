import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Skills } from "@/components/Skills";
import { Projects } from "@/components/Projects";
import { About } from "@/components/About";
import { Contact } from "@/components/Contact";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Vigneshwaran S — Software Developer & UI/UX Designer" },
      {
        name: "description",
        content:
          "Portfolio of Vigneshwaran S, a B.Tech graduate building scalable web applications and crafting intuitive digital experiences.",
      },
      { property: "og:title", content: "Vigneshwaran S — Software Developer & UI/UX Designer" },
      {
        property: "og:description",
        content:
          "Portfolio of Vigneshwaran S — building scalable web apps and designing intuitive digital experiences.",
      },
    ],
  }),
});

function Index() {
  return (
    <main className="relative overflow-x-hidden">
      <Navbar />
      <Hero />
      <Skills />
      <Projects />
      <About />
      <Contact />
    </main>
  );
}
